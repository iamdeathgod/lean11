@echo off
setlocal
title Lean11

rem --- Re-launch elevated if needed ---
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting Administrator rights...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Lean11.ps1" -Level Balanced

echo.
echo Press any key to close.
pause >nul
