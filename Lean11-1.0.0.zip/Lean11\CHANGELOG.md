# Changelog

## 1.0.0

First public release.

- Three levels: Safe, Balanced, Aggressive.
- `-DryRun` preview mode that lists every change without applying it.
- Per-run backup folder with services, tasks, app list, registry state and a
  machine-readable report.
- `Rollback.ps1` restores services, tasks and registry values from the newest
  backup.
- Edge auto-launch entries are now matched by pattern instead of a hardcoded
  machine-specific registry name.
- Removed the machine-specific "kill hung process by PID" workaround from the
  original internal script.
- Irreversible operations (`C:\Windows.old`, DISM `/ResetBase`, reserved
  storage) are isolated to the Aggressive level.
- Print Spooler, Windows Search and per-user services are only touched at
  Aggressive level, and are set to Manual rather than Disabled.
- Released free for personal use under the PolyForm Noncommercial License
  1.0.0 (`LICENSE`). Commercial use requires a separate paid licence.
