@echo off
setlocal
title Lean11 - Preview (no changes)

echo ============================================================
echo   Lean11 PREVIEW
echo   This shows what Lean11 would change. Nothing is modified.
echo ============================================================
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Lean11.ps1" -DryRun -Level Balanced

echo.
echo Press any key to close.
pause >nul
