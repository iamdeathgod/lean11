# =====================================================================
#  Lean11 - Rollback
#  Restores services, scheduled tasks and registry values captured by
#  Lean11.ps1 before it made changes.
#
#  Usage:
#    Rollback.ps1 -Latest
#    Rollback.ps1 -BackupFolder "C:\path\to\backup-20260101-120000"
#
#  NOTE: apps removed by Lean11 cannot be reinstalled automatically.
#  Rollback.ps1 lists them so you can reinstall from the Microsoft Store.
# =====================================================================
[CmdletBinding()]
param(
    [string]$BackupFolder,
    [switch]$Latest
)

$ErrorActionPreference = 'Continue'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

function Log  { param([string]$m) Write-Host ("[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $m) }
function Warn { param([string]$m) Write-Host ("[{0}] ! {1}" -f (Get-Date -Format 'HH:mm:ss'), $m) -ForegroundColor Yellow }

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host 'Rollback must run as Administrator.' -ForegroundColor Red
    Write-Host 'Right-click Run-Rollback.cmd and choose "Run as administrator".' -ForegroundColor Red
    exit 1
}

if ($Latest -or -not $BackupFolder) {
    $candidates = Get-ChildItem -Path $root -Directory -Filter 'backup-*' -ErrorAction SilentlyContinue |
                  Sort-Object Name -Descending
    if (-not $candidates) {
        Write-Host 'No backup folders found next to Rollback.ps1.' -ForegroundColor Red
        exit 1
    }
    $BackupFolder = $candidates[0].FullName
    Log ('Using most recent backup: {0}' -f $BackupFolder)
}

if (-not (Test-Path $BackupFolder)) {
    Write-Host ('Backup folder not found: {0}' -f $BackupFolder) -ForegroundColor Red
    exit 1
}

# ---- services ----
$svcCsv = Join-Path $BackupFolder 'services.csv'
if (Test-Path $svcCsv) {
    Log 'Restoring service start types...'
    foreach ($r in (Import-Csv $svcCsv)) {
        try {
            $cur = Get-Service -Name $r.Name -ErrorAction SilentlyContinue
            if ($cur -and $cur.StartType -ne $r.StartType) {
                Set-Service -Name $r.Name -StartupType $r.StartType -ErrorAction Stop
                Log ('  {0} -> {1}' -f $r.Name, $r.StartType)
            }
        } catch {}
    }
}

# ---- scheduled tasks ----
$taskCsv = Join-Path $BackupFolder 'tasks.csv'
if (Test-Path $taskCsv) {
    Log 'Restoring scheduled tasks...'
    foreach ($r in (Import-Csv $taskCsv)) {
        if ($r.State -ne 'Disabled') {
            try { Enable-ScheduledTask -TaskPath $r.TaskPath -TaskName $r.TaskName -ErrorAction Stop | Out-Null } catch {}
        }
    }
}

# ---- registry ----
$regJson = Join-Path $BackupFolder 'registry.json'
if (Test-Path $regJson) {
    Log 'Restoring registry values...'
    try {
        $items = Get-Content $regJson -Raw | ConvertFrom-Json
        foreach ($i in $items) {
            try {
                if ($i.Had) {
                    if (-not (Test-Path $i.Path)) { New-Item -Path $i.Path -Force | Out-Null }
                    $t = switch ($i.Type) { 'DWord' { 'DWord' } 'QWord' { 'QWord' } 'String' { 'String' } default { 'String' } }
                    New-ItemProperty -Path $i.Path -Name $i.Name -Value $i.Old -PropertyType $t -Force | Out-Null
                } else {
                    Remove-ItemProperty -Path $i.Path -Name $i.Name -Force -ErrorAction SilentlyContinue
                }
            } catch {}
        }
    } catch {
        Warn ('Could not read registry backup: {0}' -f $_.Exception.Message)
    }
}

# ---- removed apps (manual reinstall) ----
$appTxt = Join-Path $BackupFolder 'removed-appx.txt'
if (Test-Path $appTxt) {
    Write-Host ''
    Log 'These apps were removed and must be reinstalled from the Microsoft Store:'
    Get-Content $appTxt | ForEach-Object { Log ('  - {0}' -f $_) }
}

Write-Host ''
Log 'Rollback finished. Restart your PC to finish.'
Write-Host ''
