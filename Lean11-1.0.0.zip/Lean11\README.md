# Lean11

**A cleaner, quieter Windows 11 — in one click, with a one-click undo.**

Lean11 turns off telemetry, removes bundled apps you never asked for, and reclaims disk space. Every change is recorded in a backup folder, so you can see exactly what happened and roll it back.

---

## Quick start

1. Unzip the folder anywhere (your Desktop is fine).
2. **Preview first.** Double-click `Preview.cmd`. This shows every change Lean11 *would* make and changes nothing.
3. Happy with it? Right-click `Run-Lean11.cmd` → **Run as administrator**.
4. Restart your PC when it finishes.

That's it. There is no installer and nothing is left running in the background.

---

## What the levels do

| | **Safe** | **Balanced** (default) | **Aggressive** |
|---|---|---|---|
| Privacy + telemetry settings | ✅ | ✅ | ✅ |
| Disable telemetry / CEIP tasks | ✅ | ✅ | ✅ |
| Disable background services | — | ✅ | ✅ |
| Remove bundled apps | — | ✅ | ✅ + extras |
| Temp / recycle bin cleanup | — | ✅ | ✅ |
| Windows Update download cache | — | — | ✅ |
| `C:\Windows.old` removal | — | — | ✅ |
| Reserved storage + hibernation shrink | — | — | ✅ |
| DISM component cleanup (`/ResetBase`) | — | — | ✅ |

**Start with Balanced.** Use Safe on a work laptop where you want privacy tweaks and nothing else. Use Aggressive on a machine you can afford to reinstall.

To run a specific level, open PowerShell in this folder and run:

```
powershell -ExecutionPolicy Bypass -File .\Lean11.ps1 -Level Aggressive
```

---

## Undo

Every run creates a folder called `backup-<date>-<time>` containing:

- `services.csv` — the state of every service before the run
- `tasks.csv` — the state of every scheduled task
- `appx.csv` — installed apps before the run
- `registry.json` — every registry value changed, with its old value
- `removed-appx.txt` — apps that were removed
- `report.json` — before/after numbers
- `lean11.log` — the full log

To undo, right-click `Run-Rollback.cmd` → **Run as administrator**. It uses the most recent backup folder and restores services, tasks and registry values.

**One limitation, stated plainly:** Windows does not let a script reinstall Store apps that have been removed. Rollback lists them for you so you can reinstall the ones you want from the Microsoft Store. This is why `Preview.cmd` exists — check the app list before you commit.

If a restore point was created, you can also use **System Restore** (Start → "Create a restore point" → System Restore).

---

## What Lean11 does not touch

- Windows Update itself (only the download cache, and only on Aggressive)
- Microsoft Defender / Windows Security
- Your files, documents, photos or OneDrive contents
- The Microsoft Store
- Your Wi-Fi, network or user account
- Drivers

---

## Requirements

- Windows 11 (build 22000 or newer). Windows 10 works for most tweaks but is not the target.
- Administrator rights (needed to change services and remove apps).
- PowerShell 5.1 or newer — already included in Windows.

---

## Troubleshooting

**"Running scripts is disabled on this system"**
You opened the `.ps1` directly. Use `Preview.cmd` / `Run-Lean11.cmd` instead — they set the execution policy for that one run only.

**SmartScreen says "Windows protected your PC"**
Lean11 is a PowerShell script, not a signed installer. Click **More info → Run anyway**. You can open every `.ps1` file in Notepad and read exactly what it does before running it — that is the point of shipping it as plain text.

**The restore point step seems to hang**
Windows can take several minutes to create a restore point. If it is stuck for more than 10 minutes, close the window and run again with `-NoRestorePoint`:

```
powershell -ExecutionPolicy Bypass -File .\Lean11.ps1 -NoRestorePoint
```

Your changes are still backed up in the `backup-*` folder either way.

**Something broke**
Run `Run-Rollback.cmd`, then restart. If that does not fix it, use System Restore.

---

## Price

Lean11 is free for personal use. There is no trial timer, no account and no
paid tier hiding the useful parts. It is source-available under the PolyForm
Noncommercial License 1.0.0, which means you can read it, change it and share
it for noncommercial purposes.

If it saved you an afternoon, you can leave an optional tip from the download
page. A tip does not unlock anything; the download is the whole product.

Using Lean11 at work, or shipping it inside something you sell, needs a
commercial licence. Ask at **support@example.com**.

---

## Support

Email **support@example.com** with your `backup-*` folder attached (it contains no personal files — only service and registry state).

---

## License

Lean11 is released under the **PolyForm Noncommercial License 1.0.0**. The
full text is in `LICENSE`. It is source-available, not OSI-approved open
source: personal and other noncommercial use is permitted; commercial use
requires a separate paid licence.

The software is provided as-is. See `EULA.txt` for the risk notice.

