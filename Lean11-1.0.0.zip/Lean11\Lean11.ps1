# =====================================================================
#  Lean11 - Windows 11 cleanup, privacy hardening and disk reclaim
#  Version 1.0.0
#
#  PREVIEW (no changes made):  Lean11.ps1 -DryRun
#  APPLY:                      Run-Lean11.cmd  (as Administrator)
#
#  Every change is logged and backed up to a backup-<timestamp> folder
#  next to this script. See README.md for how to undo.
# =====================================================================
[CmdletBinding()]
param(
    [ValidateSet('Safe','Balanced','Aggressive')]
    [string]$Level = 'Balanced',

    [switch]$DryRun,
    [switch]$NoRestorePoint,
    [switch]$SkipCleanup,
    [switch]$SkipApps
)

$ErrorActionPreference = 'Continue'

$script:Version = '1.0.0'
$script:Stamp   = Get-Date -Format 'yyyyMMdd-HHmmss'
$script:Root    = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:Backup  = Join-Path $script:Root ("backup-$script:Stamp")
$script:Changes = 0
$script:Failures = 0

function Log  { param([string]$m) Write-Host ("[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $m) }
function Warn { param([string]$m) Write-Host ("[{0}] ! {1}" -f (Get-Date -Format 'HH:mm:ss'), $m) -ForegroundColor Yellow }
function Section { param([string]$m) Write-Host ''; Write-Host ("===== {0} =====" -f $m) -ForegroundColor Cyan }

# ---------------------------------------------------------------------
# Preflight
# ---------------------------------------------------------------------
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin -and -not $DryRun) {
    Write-Host ''
    Write-Host 'Lean11 needs Administrator rights to change services and remove apps.' -ForegroundColor Red
    Write-Host 'Right-click Run-Lean11.cmd and choose "Run as administrator".' -ForegroundColor Red
    Write-Host 'To preview without changing anything, run Preview.cmd instead.' -ForegroundColor Red
    Write-Host ''
    exit 1
}

$osInfo = Get-CimInstance Win32_OperatingSystem
$build  = [int]$osInfo.BuildNumber
if ($build -lt 22000) {
    Warn ("Lean11 is designed for Windows 11 (build 22000+). This PC reports build {0}." -f $build)
    Warn 'Some tweaks may not exist on older versions. They will be skipped automatically.'
}

if ($DryRun) {
    Write-Host ''
    Write-Host '  PREVIEW MODE - nothing on this PC will be changed.' -ForegroundColor Green
    Write-Host ('  Level: {0}' -f $Level) -ForegroundColor Green
    Write-Host ''
}

# ---------------------------------------------------------------------
# Backup folder + transcript
# ---------------------------------------------------------------------
if (-not $DryRun) {
    New-Item -ItemType Directory -Path $script:Backup -Force | Out-Null
    try { Start-Transcript -Path (Join-Path $script:Backup 'lean11.log') -Force | Out-Null } catch {}
}

$beforeFreeGB  = [math]::Round((Get-PSDrive C).Free / 1GB, 2)
$beforeUsedPct = [math]::Round((1 - $osInfo.FreePhysicalMemory / $osInfo.TotalVisibleMemorySize) * 100, 1)
Log ('Windows build {0}  |  RAM used: {1}%  |  C: free: {2} GB' -f $build, $beforeUsedPct, $beforeFreeGB)
if (-not $DryRun) { Log ('Backup folder: {0}' -f $script:Backup) }

# ---------------------------------------------------------------------
# Change helpers (all respect -DryRun)
# ---------------------------------------------------------------------
$script:RegBackup = New-Object System.Collections.ArrayList

function Set-RegValue {
    param([string]$Path, [string]$Name, $Value, [string]$Type = 'DWord')

    if ($DryRun) {
        Log ('  [preview] set {0}\{1} = {2}' -f $Path, $Name, $Value)
        $script:Changes++
        return
    }
    try {
        if (-not (Test-Path $Path)) { New-Item -Path $Path -Force | Out-Null }
        $had = $false; $old = $null
        try { $old = (Get-ItemProperty -Path $Path -Name $Name -ErrorAction Stop).$Name; $had = $true } catch {}
        [void]$script:RegBackup.Add([pscustomobject]@{ Action='Set'; Path=$Path; Name=$Name; Had=$had; Old=$old; Type=$Type })
        New-ItemProperty -Path $Path -Name $Name -Value $Value -PropertyType $Type -Force | Out-Null
        $script:Changes++
    } catch {
        Warn ('  registry set failed: {0}\{1}' -f $Path, $Name)
        $script:Failures++
    }
}

function Remove-RegValue {
    param([string]$Path, [string]$Name)

    if (-not (Test-Path $Path)) { return }
    if ($DryRun) {
        try {
            $null = Get-ItemProperty -Path $Path -Name $Name -ErrorAction Stop
            Log ('  [preview] remove startup value {0}\{1}' -f $Path, $Name)
            $script:Changes++
        } catch {}
        return
    }
    try {
        $had = $false; $old = $null
        try { $old = (Get-ItemProperty -Path $Path -Name $Name -ErrorAction Stop).$Name; $had = $true } catch {}
        if ($had) {
            [void]$script:RegBackup.Add([pscustomobject]@{ Action='Set'; Path=$Path; Name=$Name; Had=$true; Old=$old; Type='String' })
            Remove-ItemProperty -Path $Path -Name $Name -Force -ErrorAction SilentlyContinue
            Log ('  removed startup value: {0}\{1}' -f $Path, $Name)
            $script:Changes++
        }
    } catch {
        Warn ('  could not remove {0}\{1}' -f $Path, $Name)
        $script:Failures++
    }
}

function Remove-RegValuePattern {
    param([string]$Path, [string]$Pattern)

    if (-not (Test-Path $Path)) { return }
    try {
        $props = (Get-ItemProperty -Path $Path).PSObject.Properties |
                 Where-Object { $_.Name -notlike 'PS*' -and $_.Name -match $Pattern }
        foreach ($p in $props) { Remove-RegValue $Path $p.Name }
    } catch {}
}

function Set-Svc {
    param([string]$Name, [string]$Startup)

    $svc = Get-Service -Name $Name -ErrorAction SilentlyContinue
    if (-not $svc) { return }

    if ($DryRun) {
        Log ('  [preview] service {0,-34} -> {1}' -f $Name, $Startup)
        $script:Changes++
        return
    }
    $changed = $false
    try {
        if ($svc.StartType -ne $Startup) {
            Set-Service -Name $Name -StartupType $Startup -ErrorAction Stop
            $changed = $true
        }
    } catch {
        $scMap = @{ 'Disabled' = 'disabled'; 'Manual' = 'demand'; 'Automatic' = 'auto' }
        & sc.exe config $Name start= $scMap[$Startup] | Out-Null
        if ($LASTEXITCODE -eq 0) { $changed = $true }
    }
    if ($changed) {
        Log ('  service {0,-34} -> {1}' -f $Name, $Startup)
        $script:Changes++
        if ($Startup -eq 'Disabled') {
            try { Stop-Service -Name $Name -Force -ErrorAction SilentlyContinue } catch {}
        }
    }
}

function Disable-TaskItem {
    param([string]$TaskPath, [string]$TaskName)

    $full = $TaskPath + $TaskName
    try {
        $task = Get-ScheduledTask -TaskPath $TaskPath -TaskName $TaskName -ErrorAction Stop
    } catch { return }

    if ($task.State -eq 'Disabled') { return }

    if ($DryRun) {
        Log ('  [preview] disable scheduled task: {0}' -f $full)
        $script:Changes++
        return
    }
    try {
        Disable-ScheduledTask -TaskPath $TaskPath -TaskName $TaskName -ErrorAction Stop | Out-Null
        Log ('  disabled scheduled task: {0}' -f $full)
        $script:Changes++
    } catch {
        Warn ('  could not disable task: {0}' -f $full)
        $script:Failures++
    }
}

function Remove-AppItem {
    param([string]$Name)

    $pkg = Get-AppxPackage -Name $Name -ErrorAction SilentlyContinue
    if (-not $pkg) { return }

    if ($DryRun) {
        Log ('  [preview] remove app: {0}' -f $Name)
        $script:Changes++
        return
    }
    $done = $false
    try {
        $pkg | Remove-AppxPackage -AllUsers -ErrorAction Stop
        $done = $true
    } catch {
        try { $pkg | Remove-AppxPackage -ErrorAction Stop; $done = $true } catch {}
    }
    if ($done) {
        Log ('  removed app: {0}' -f $Name)
        $script:Changes++
        try { [void]($script:RemovedApps.Add($Name)) } catch {}
    } else {
        Warn ('  could not remove app: {0}' -f $Name)
        $script:Failures++
    }

    # Stop it coming back for new users
    try {
        $prov = Get-AppxProvisionedPackage -Online -ErrorAction Stop | Where-Object { $_.DisplayName -eq $Name }
        if ($prov) { $prov | Remove-AppxProvisionedPackage -Online -ErrorAction Stop | Out-Null }
    } catch {}
}

function Clean-Dir {
    param([string]$Path, [string]$Exclude)

    if (-not (Test-Path $Path)) { return }

    if ($DryRun) {
        Log ('  [preview] clean: {0}' -f $Path)
        $script:Changes++
        return
    }
    try {
        Get-ChildItem -Path $Path -Force -ErrorAction SilentlyContinue |
            Where-Object { -not $Exclude -or $_.Name -notmatch $Exclude } |
            ForEach-Object { Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue }
        Log ('  cleaned: {0}' -f $Path)
        $script:Changes++
    } catch {
        Warn ('  clean failed: {0}' -f $Path)
        $script:Failures++
    }
}

# ---------------------------------------------------------------------
# Back up current configuration (so Rollback.ps1 can undo)
# ---------------------------------------------------------------------
if (-not $DryRun) {
    Section 'Saving current configuration'
    try {
        Get-Service | Select-Object Name,DisplayName,StartType,Status |
            Export-Csv (Join-Path $script:Backup 'services.csv') -NoTypeInformation -Encoding UTF8
        Get-ScheduledTask | Select-Object TaskPath,TaskName,State |
            Export-Csv (Join-Path $script:Backup 'tasks.csv') -NoTypeInformation -Encoding UTF8
        Get-AppxPackage | Select-Object Name,PackageFullName,InstallLocation |
            Export-Csv (Join-Path $script:Backup 'appx.csv') -NoTypeInformation -Encoding UTF8
        Get-CimInstance Win32_StartupCommand | Select-Object Name,Command,Location,User |
            Export-Csv (Join-Path $script:Backup 'startup.csv') -NoTypeInformation -Encoding UTF8
        Log 'Backup written.'
    } catch {
        Warn ('Backup warning: {0}' -f $_.Exception.Message)
    }
}

# ---------------------------------------------------------------------
# System Restore point (best effort)
# ---------------------------------------------------------------------
if (-not $DryRun -and -not $NoRestorePoint -and $Level -ne 'Safe') {
    Section 'Creating a System Restore point'
    Log 'This can take a few minutes on slower drives. Please wait...'
    try {
        try {
            Set-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore' `
                -Name SystemRestorePointCreationFrequency -Value 0 -Type DWord -Force -ErrorAction SilentlyContinue
        } catch {}
        Enable-ComputerRestore -Drive 'C:\' -ErrorAction Stop
        Checkpoint-Computer -Description "Lean11 $script:Stamp" -RestorePointType MODIFY_SETTINGS -ErrorAction Stop
        Log 'Restore point created.'
    } catch {
        Warn ('Restore point not created: {0}' -f $_.Exception.Message)
        Warn 'Continuing - your changes are still backed up in the backup folder.'
    }
}

# =====================================================================
# PHASE 1 - Privacy, telemetry, suggestions, background apps
# =====================================================================
Section 'Phase 1 - Privacy and telemetry'

$regOps = @(
    @{P='HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection'; N='AllowTelemetry'; V=0},
    @{P='HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection'; N='DoNotShowFeedbackNotifications'; V=1},
    @{P='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection'; N='AllowTelemetry'; V=0},
    @{P='HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent'; N='DisableWindowsConsumerFeatures'; V=1},
    @{P='HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent'; N='DisableSoftLanding'; V=1},
    @{P='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager'; N='SoftLandingEnabled'; V=0},
    @{P='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager'; N='SubscribedContent-338389Enabled'; V=0},
    @{P='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager'; N='SubscribedContent-353698Enabled'; V=0},
    @{P='HKCU:\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot'; N='TurnOffWindowsCopilot'; V=1},
    @{P='HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot'; N='TurnOffWindowsCopilot'; V=1},
    @{P='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; N='ShowCopilotButton'; V=0},
    @{P='HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsAI'; N='DisableAIDataAnalysis'; V=1},
    @{P='HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsAI'; N='AllowRecallEnablement'; V=0},
    @{P='HKCU:\SOFTWARE\Policies\Microsoft\Windows\WindowsAI'; N='DisableAIDataAnalysis'; V=1},
    @{P='HKLM:\SOFTWARE\Policies\Microsoft\Dsh'; N='AllowNewsAndInterests'; V=0},
    @{P='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; N='TaskbarDa'; V=0},
    @{P='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; N='TaskbarMn'; V=0},
    @{P='HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer'; N='DisableSearchBoxSuggestions'; V=1},
    @{P='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications'; N='GlobalUserDisabled'; V=1},
    @{P='HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy'; N='LetAppsRunInBackground'; V=2},
    @{P='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo'; N='Enabled'; V=0},
    @{P='HKCU:\SOFTWARE\Microsoft\Siuf\Rules'; N='NumberOfSIUFInPeriod'; V=0},
    @{P='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Privacy'; N='PublishUserActivities'; V=0},
    @{P='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Privacy'; N='TailoredExperiencesWithDiagnosticDataEnabled'; V=0},
    @{P='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; N='Start_IrisRecommendations'; V=0},
    @{P='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; N='ShowSyncProviderNotifications'; V=0},
    @{P='HKCU:\System\GameConfigStore'; N='GameDVR_Enabled'; V=0},
    @{P='HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR'; N='AllowGameDVR'; V=0},
    @{P='HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization'; N='DODownloadMode'; V=1},
    @{P='HKLM:\SYSTEM\CurrentControlSet\Control\Remote Assistance'; N='fAllowToGetHelp'; V=0},
    @{P='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize'; N='EnableTransparency'; V=0},
    @{P='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects\TaskbarAnimations'; N='TaskbarAnimations'; V=0},
    @{P='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy'; N='01'; V=1},
    @{P='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy'; N='04'; V=1},
    @{P='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy'; N='08'; V=1},
    @{P='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy'; N='32'; V=1},
    @{P='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy'; N='2048'; V=1},
    @{P='HKCU:\SOFTWARE\Policies\Microsoft\Edge'; N='StartupBoostEnabled'; V=0},
    @{P='HKCU:\SOFTWARE\Policies\Microsoft\Edge'; N='BackgroundModeEnabled'; V=0},
    @{P='HKLM:\SOFTWARE\Policies\Microsoft\Edge'; N='StartupBoostEnabled'; V=0},
    @{P='HKLM:\SOFTWARE\Policies\Microsoft\Edge'; N='BackgroundModeEnabled'; V=0},
    @{P='HKLM:\SOFTWARE\Policies\Microsoft\Windows\OneDrive'; N='DisableFileSyncNGSC'; V=1}
)

foreach ($op in $regOps) { Set-RegValue $op.P $op.N $op.V 'DWord' }

Section 'Startup entries'
Remove-RegValue 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run' 'OneDriveSetup'
Remove-RegValue 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run' 'OneDrive'
Remove-RegValue 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run' 'OneDriveSetup'
Remove-RegValuePattern 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run' '^MicrosoftEdgeAutoLaunch_'

if (-not $DryRun) {
    try { Get-Process OneDrive -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue } catch {}
}

# =====================================================================
# PHASE 2 - Scheduled tasks (telemetry / CEIP / diagnostics)
# =====================================================================
Section 'Phase 2 - Scheduled tasks'

$tasks = @(
    @{P='\Microsoft\Windows\Application Experience\'; N='Microsoft Compatibility Appraiser'},
    @{P='\Microsoft\Windows\Application Experience\'; N='ProgramDataUpdater'},
    @{P='\Microsoft\Windows\Customer Experience Improvement Program\'; N='Consolidator'},
    @{P='\Microsoft\Windows\Customer Experience Improvement Program\'; N='UsbCeip'},
    @{P='\Microsoft\Windows\Feedback\Siuf\'; N='DmClient'},
    @{P='\Microsoft\Windows\Feedback\Siuf\'; N='DmClientOnScenarioDownload'},
    @{P='\Microsoft\Windows\Windows Error Reporting\'; N='QueueReporting'},
    @{P='\Microsoft\Windows\Autochk\'; N='Proxy'},
    @{P='\Microsoft\Windows\CloudExperienceHost\'; N='CreateObjectTask'},
    @{P='\Microsoft\Windows\DiskDiagnostic\'; N='Microsoft-Windows-DiskDiagnosticDataCollector'},
    @{P='\Microsoft\Windows\Maintenance\'; N='WinSAT'},
    @{P='\Microsoft\Windows\PI\'; N='Sqm-Tasks'},
    @{P='\Microsoft\Windows\NetTrace\'; N='GatherNetworkInfo'},
    @{P='\Microsoft\Windows\Diagnosis\'; N='Scheduled'},
    @{P='\Microsoft\Windows\Windows Media Sharing\'; N='UpdateLibrary'},
    @{P='\Microsoft\Windows\Maps\'; N='MapsToastTask'},
    @{P='\Microsoft\Windows\Maps\'; N='MapsUpdateTask'},
    @{P='\Microsoft\Windows\Sustainability\'; N='SustainabilityTelemetry'},
    @{P='\Microsoft\Windows\PerformanceTrace\'; N='ShowFeedbackToast'},
    @{P='\Microsoft\Windows\Work Folders\'; N='Work Folders Maintenance Work'}
)

foreach ($t in $tasks) { Disable-TaskItem -TaskPath $t.P -TaskName $t.N }

# =====================================================================
# PHASE 3 - Services (Balanced and Aggressive only)
# =====================================================================
if ($Level -ne 'Safe') {
    Section 'Phase 3 - Services'

    $svcDisable = @(
        'DiagTrack','dmwappushservice','DiagnosticsHub.StandardCollector.Service',
        'WMPNetworkSvc','RemoteRegistry','RemoteAccess','Fax','RetailDemo',
        'MapsBroker','WpcMonSvc','wisvc','PushToInstall','AJRouter','ALG',
        'AppVClient','NetTcpPortSharing','SharedAccess',
        'XblAuthManager','XblGameSave','XboxGipSvc','XboxNetApiSvc',
        'WSAIFabricSvc','wuqisvc','SEMgrSvc','SDRSVC','PhoneSvc','WalletService'
    )
    $svcManual = @(
        'lfsvc','FrameServer','stisvc','WbioSrvc','SensorService','RmSvc',
        'SstpSvc','seclogon','lmhosts','TrkWks','EFS','DsmSvc','NetSetupSvc',
        'InventorySvc','AppReadiness','CloudBackupRestoreSvc','InstallService',
        'CDPSvc','DusmSvc','NcbService','PcaSvc','DPS','WdiServiceHost',
        'WdiSystemHost','WerSvc','whesvc','DoSvc','iphlpsvc',
        'SSDPSRV','upnphost','fdPHost','FDResPub'
    )

    foreach ($s in $svcDisable) { Set-Svc -Name $s -Startup 'Disabled' }
    foreach ($s in $svcManual)  { Set-Svc -Name $s -Startup 'Manual' }

    if ($Level -eq 'Aggressive') {
        # Printing / indexing stay available on demand instead of always running.
        foreach ($s in @('Spooler','PrintNotify','WSearch')) { Set-Svc -Name $s -Startup 'Manual' }

        foreach ($s in @('OneSyncSvc','PimIndexMaintenanceSvc','UnistoreSvc','UserDataSvc','ContactData')) {
            $k = "HKLM:\SYSTEM\CurrentControlSet\Services\$s"
            if (Test-Path $k) { Set-RegValue $k 'Start' 3 'DWord' }
        }
    }
}

# =====================================================================
# PHASE 4 - Remove bundled consumer apps (Balanced and Aggressive)
# =====================================================================
if ($Level -ne 'Safe' -and -not $SkipApps) {
    Section 'Phase 4 - Removing bundled apps'

    $appCore = @(
        'Microsoft.GamingApp','Microsoft.XboxGamingOverlay','Microsoft.Xbox.TCUI',
        'Microsoft.XboxIdentityProvider','Microsoft.XboxGameCallableUI',
        'Microsoft.XboxSpeechToTextOverlay','Microsoft.BingSearch',
        'Microsoft.BingNews','Microsoft.BingWeather','Microsoft.MicrosoftSolitaireCollection',
        'Clipchamp.Clipchamp','Microsoft.Todos','Microsoft.GetHelp','Microsoft.Getstarted',
        'Microsoft.People','Microsoft.WindowsFeedbackHub','Microsoft.Microsoft3DViewer',
        'Microsoft.MixedReality.Portal','Microsoft.SkypeApp','Microsoft.OneConnect',
        'Microsoft.Print3D','Microsoft.MicrosoftJournal','MicrosoftTeams',
        'Microsoft.Family','Microsoft.News','Microsoft.Windows.ParentalControls',
        'Microsoft.YourPhone','Microsoft.Windows.DevHome','Microsoft.PowerAutomateDesktop',
        'MicrosoftCorporationII.QuickAssist','Microsoft.MicrosoftOfficeHub',
        'Microsoft.ZuneMusic','Microsoft.ZuneVideo','Microsoft.WindowsMaps','Microsoft.Wallet'
    )

    $script:RemovedApps = New-Object System.Collections.ArrayList
    foreach ($a in $appCore) { Remove-AppItem $a }

    if ($Level -eq 'Aggressive') {
        foreach ($a in @('Microsoft.MSPaint','Microsoft.WindowsSoundRecorder','MicrosoftWindows.CrossDevice')) {
            Remove-AppItem $a
        }
    }

    if (-not $DryRun) {
        try {
            $script:RemovedApps | Set-Content (Join-Path $script:Backup 'removed-appx.txt') -Encoding UTF8
        } catch {}
    }
}

# =====================================================================
# PHASE 5 - Disk cleanup (Balanced and Aggressive)
# =====================================================================
if ($Level -ne 'Safe' -and -not $SkipCleanup) {
    Section 'Phase 5 - Reclaiming disk space'

    Clean-Dir $env:TEMP 'lean11'
    Clean-Dir 'C:\Windows\Temp'
    Clean-Dir 'C:\ProgramData\Microsoft\Windows\WER\ReportQueue'
    Clean-Dir 'C:\ProgramData\Microsoft\Windows\WER\ReportArchive'

    if (-not $DryRun) {
        try {
            Get-ChildItem 'C:\Windows\Logs\CBS' -Filter *.cab -Force -ErrorAction SilentlyContinue |
                Remove-Item -Force -ErrorAction SilentlyContinue
        } catch {}
        try { Delete-DeliveryOptimizationCache -Force -ErrorAction SilentlyContinue; Log '  cleared delivery optimization cache' } catch {}
        try { Clear-RecycleBin -Force -ErrorAction SilentlyContinue; Log '  emptied recycle bin' } catch {}
    } else {
        Log '  [preview] clear delivery optimization cache'
        Log '  [preview] empty recycle bin'
        $script:Changes += 2
    }

    if ($Level -eq 'Aggressive') {
        Section 'Phase 6 - Deep cleanup (Aggressive)'

        try {
            if (-not $DryRun) {
                Stop-Service wuauserv,bits,dosvc -Force -ErrorAction SilentlyContinue
                Start-Sleep -Seconds 2
            }
            Clean-Dir 'C:\Windows\SoftwareDistribution\Download'
            if (-not $DryRun) { Start-Service wuauserv -ErrorAction SilentlyContinue }
        } catch { Warn '  update cache cleanup failed' }

        if (Test-Path 'C:\Windows.old') {
            if ($DryRun) {
                Log '  [preview] remove C:\Windows.old (can free several GB)'
                $script:Changes++
            } else {
                Log '  removing C:\Windows.old (this can take a while)'
                try {
                    & takeown.exe /f 'C:\Windows.old' /r /d y 2>$null | Out-Null
                    & icacls.exe 'C:\Windows.old' /grant Administrators:F /t /c /q 2>$null | Out-Null
                    Remove-Item 'C:\Windows.old' -Recurse -Force -ErrorAction SilentlyContinue
                    if (Test-Path 'C:\Windows.old') { & cmd.exe /c 'rd /s /q C:\Windows.old' 2>$null }
                    Log '  removed C:\Windows.old'
                    $script:Changes++
                } catch { Warn '  C:\Windows.old removal failed' }
            }
        }

        if ($DryRun) {
            Log '  [preview] disable reserved storage (~7 GB)'
            Log '  [preview] reduce hibernation file to 40% of RAM'
            Log '  [preview] run DISM component cleanup /ResetBase (slow)'
            $script:Changes += 3
        } else {
            try { & Dism.exe /Online /Set-ReservedStorageState /State:Disabled 2>&1 | Out-Null; Log '  reserved storage disabled' } catch {}
            try { & powercfg.exe /hibernate /size 40 2>&1 | Out-Null; Log '  hibernation file reduced to 40%' } catch {}
            try {
                Log '  running DISM component cleanup (slow on hard drives)...'
                & Dism.exe /Online /Cleanup-Image /StartComponentCleanup /ResetBase 2>&1 |
                    ForEach-Object { if ($_ -match 'Error|completed|100') { Log ('    ' + $_) } }
            } catch { Warn '  DISM cleanup failed' }
        }
    }
}

# =====================================================================
# Save rollback data + report
# =====================================================================
if (-not $DryRun) {
    try {
        $script:RegBackup | ConvertTo-Json -Depth 4 | Set-Content (Join-Path $script:Backup 'registry.json') -Encoding UTF8
    } catch {}
}

Section 'Done'

if (-not $DryRun) { Start-Sleep -Seconds 2 }

$afterFreeGB  = [math]::Round((Get-PSDrive C).Free / 1GB, 2)
$afterUsedPct = [math]::Round((1 - (Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory /
                                  (Get-CimInstance Win32_OperatingSystem).TotalVisibleMemorySize) * 100, 1)

$summary = [pscustomobject]@{
    Product        = 'Lean11'
    Version        = $script:Version
    Timestamp      = $script:Stamp
    Level          = $Level
    Preview        = [bool]$DryRun
    BeforeRamPct   = $beforeUsedPct
    AfterRamPct    = $afterUsedPct
    BeforeFreeGB   = $beforeFreeGB
    AfterFreeGB    = $afterFreeGB
    FreedGB        = [math]::Round($afterFreeGB - $beforeFreeGB, 2)
    Changes        = $script:Changes
    Failures       = $script:Failures
    BackupFolder   = $(if ($DryRun) { $null } else { $script:Backup })
    RebootRecommended = (-not $DryRun -and $Level -ne 'Safe')
}

if ($DryRun) {
    Write-Host ''
    Write-Host '  PREVIEW COMPLETE - no changes were made.' -ForegroundColor Green
    Write-Host ('  Lean11 would apply about {0} changes at level "{1}".' -f $script:Changes, $Level) -ForegroundColor Green
    Write-Host '  Run Run-Lean11.cmd as Administrator to apply them.' -ForegroundColor Green
    Write-Host ''
} else {
    $summary | ConvertTo-Json -Depth 4 | Set-Content (Join-Path $script:Backup 'report.json') -Encoding UTF8
    "LEAN11_COMPLETE $script:Stamp" | Set-Content (Join-Path $script:Backup '_DONE.txt') -Encoding UTF8
    Write-Host ''
    Write-Host ('  Lean11 finished. {0} changes applied, {1} skipped.' -f $script:Changes, $script:Failures) -ForegroundColor Green
    Write-Host ('  Disk free: {0} GB -> {1} GB  ({2} GB reclaimed)' -f $beforeFreeGB, $afterFreeGB, $summary.FreedGB) -ForegroundColor Green
    Write-Host ('  Backup folder: {0}' -f $script:Backup) -ForegroundColor Green
    Write-Host '  Please restart your PC to finish.' -ForegroundColor Yellow
    Write-Host ''
}

try { Stop-Transcript | Out-Null } catch {}
exit 0
